/** ******************************************************************
                     Color Demo Client Program
   This program creates an instance of the ColorWindow class, which
	causes it to display its window. It uses the ColorWindow.java file.
  ********************************************************************/

public class ColorDemo
{
   public static void main(String[] args)
   {
      ColorWindow cw = new ColorWindow();
   }
}
