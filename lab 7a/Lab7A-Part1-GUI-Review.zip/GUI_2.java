/** ******************************************
   GUI Review Exercise 2
   This program creates an instance of the
   KiloConverterWindow class, which displays
   a window on the screen.
 *********************************************/

public class GUI_2   // Demonstrates the revised KiloconverterWindow class
{
   public static void main(String[] args)
   {
      KiloConverterWindow kc = new KiloConverterWindow();
   }
}
